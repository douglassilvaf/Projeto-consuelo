import os
import csv
import xml.etree.ElementTree as ET

# Diretório contendo os arquivos XML
xml_directory = r"C:\Users\douglas.ferreira\Pictures\materias\casadigital\desafio\Desafio_Log\rastreamento_navios"

# Nome do arquivo CSV de saída
output_csv = "navio_tracking.csv"

# Definir os nomes das colunas para o arquivo CSV
fieldnames = ["filename", "navio_id", "nome", "timestamp", "latitude", "longitude", "velocidade", "direcao", "status"]

# Abrir o arquivo CSV para escrita
with open(output_csv, mode='w', newline='', encoding='utf-8') as csv_file:
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames, delimiter=';')
    writer.writeheader()

    # Iterar por cada arquivo XML no diretório
    for filename in os.listdir(xml_directory):
        if filename.endswith(".xml"):
            xml_path = os.path.join(xml_directory, filename)
            tree = ET.parse(xml_path)
            root = tree.getroot()

            # Extrair dados do XML
            navio_id = int(root.get("ID"))
            nome = root.find("Nome").text
            for ponto in root.findall("Rastreamento/PontoDeDados"):
                timestamp = ponto.get("Timestamp")
                latitude = float(ponto.find("Latitude").text)
                longitude = float(ponto.find("Longitude").text)
                velocidade = float(ponto.find("Velocidade").text)
                direcao = float(ponto.find("Direcao").text)
                status = ponto.find("Status").text

                # Escrever dados no arquivo CSV
                writer.writerow({
                    "filename": filename,
                    "navio_id": navio_id,
                    "nome": nome,
                    "timestamp": timestamp,
                    "latitude": latitude,
                    "longitude": longitude,
                    "velocidade": velocidade,
                    "direcao": direcao,
                    "status": status
                })

print(f"Convertidos {len(os.listdir(xml_directory))} arquivos XML para {output_csv} com sucesso.")
