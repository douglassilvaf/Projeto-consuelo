import pandas as pd

# Carregar os dados do arquivo CSV
df = pd.read_csv(r'C:\Users\douglas.ferreira\Pictures\materias\casadigital\desafio\custos_por_tipo_de_navio\teste.csv', delimiter=';')

# Converter a coluna 'Valor (USD)' para numérico, tratando possíveis problemas de leitura
df['Valor (USD)'] = df['Valor (USD)'].str.replace(',', '.').astype(float)

# Calcular a soma total gasta por dia
total_por_dia = df.groupby('Tipo de Custo')['Valor (USD)'].sum().reset_index()

# Salvar o resultado em um novo arquivo CSV no mesmo formato anterior
total_por_dia.to_csv(r'C:\Users\douglas.ferreira\Pictures\materias\casadigital\desafio\custos_por_tipo_de_navio\total_por_Tipo_de_Custo.csv', index=False, sep=';', float_format='%.2f')
