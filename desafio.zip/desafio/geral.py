import pandas as pd

# Carregar os arquivos CSV necessários
multas_df = pd.read_csv('multas_portuarias_atualizado.csv', delimiter=';')
navio_tracking_df = pd.read_csv('navio_tracking.csv', delimiter=';')

# Realizar a fusão
final_df = pd.merge(multas_df, navio_tracking_df, left_on='ID_Navio', right_on='navio_id', how='left')

# Verificar as colunas de final_df
print(final_df.columns.tolist())

# Verificar se a coluna 'Valor' está presente
if 'Valor' in final_df.columns:
    # Calcular valores mínimos, máximos e estatísticas descritivas
    min_multa = final_df['Valor'].min()
    max_multa = final_df['Valor'].max()
    descricao_multa = final_df['Valor'].describe()

    print(f"Valor mínimo da multa: {min_multa}")
    print(f"Valor máximo da multa: {max_multa}")
    print("Estatísticas descritivas das multas:")
    print(descricao_multa)

    # Histograma para visualizar a distribuição
    import matplotlib.pyplot as plt

    plt.figure(figsize=(10, 6))
    plt.hist(final_df['Valor'].dropna(), bins=20, edgecolor='black')
    plt.title('Distribuição dos Valores das Multas')
    plt.xlabel('Valor da Multa (USD)')
    plt.ylabel('Número de Multas')
    plt.grid(True)
    plt.show()
else:
    print("A coluna 'Valor' não está presente em final_df.")
