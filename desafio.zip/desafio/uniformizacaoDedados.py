import pandas as pd
import matplotlib.pyplot as plt

# Carregar as tabelas
navio_tracking = pd.read_csv('navio_tracking.csv', delimiter=';')
portos = pd.read_csv('portos.csv', delimiter=',')

# Exibir as primeiras linhas para verificar os dados
print("Tabela Navio Tracking:")
print(navio_tracking.head())

print("\nTabela Portos:")
print(portos.head())

# Realizar o merge com base na coluna correta
combined_data = pd.merge(navio_tracking, portos, how='left', left_on='nome', right_on='Nome_Porto')

# Verificar o resultado do merge
print("\nDados Combinados:")
print(combined_data.head())

# Convertendo timestamp para datetime (ajuste o nome da coluna se necessário)
# navio_tracking['timestamp'] = pd.to_datetime(navio_tracking['timestamp'])  # Descomente se houver coluna 'timestamp'

# Calcular a média das coordenadas e da velocidade por navio
mean_data = navio_tracking.groupby('navio_id').agg({
    'latitude': 'mean',
    'longitude': 'mean',
    'velocidade': 'mean'
}).reset_index()

print("\nMédia das Coordenadas e Velocidade por Navio:")
print(mean_data)

# Plotar a movimentação dos navios
plt.figure(figsize=(10, 6))
for navio_id in navio_tracking['navio_id'].unique():
    navio_data = navio_tracking[navio_tracking['navio_id'] == navio_id]
    plt.plot(navio_data['longitude'], navio_data['latitude'], marker='o', label=f'Navio {navio_id}')

plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Movimentação dos Navios')
plt.legend()
plt.show()
