import pandas as pd

# Carregar o arquivo XLSX
nomeArquivo = str(input('Digite o nome da planilha que gostaria de editar: '))
try:
    planilhaAntiga = pd.read_excel(f'C:\\Users\\douglas.ferreira\\Pictures\\materias\\casadigital\\desafio\\custos_por_tipo_de_navio\\{nomeArquivo}.xlsx')
    # Salvar como CSV
    planilhaAntiga.to_csv(f'C:\\Users\\douglas.ferreira\\Pictures\\materias\\casadigital\\desafio\\custos_por_tipo_de_navio\\{nomeArquivo}.csv', index=False)

    print(f"O arquivo {nomeArquivo}.xlsx foi convertido para CSV e salvo como {nomeArquivo}.csv")
except FileNotFoundError:
    print(f"Arquivo '{nomeArquivo}.xlsx' não encontrado. Verifique o nome e o local do arquivo.")
except Exception as e:
    print(f"Ocorreu um erro: {e}")
