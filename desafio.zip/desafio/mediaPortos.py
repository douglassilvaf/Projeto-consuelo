import pandas as pd

# Ler o arquivo CSV
df = pd.read_csv("C:\\Users\\douglas.ferreira\\Pictures\\materias\\casadigital\\desafio\\custos_por_tipo_de_navio\\navio_carga_geral.csv", decimal=",")

# Converter os valores para números
df['Valor (USD)'] = pd.to_numeric(df['Valor (USD)'], errors='coerce')

# Calcular a média de gastos por porto
media_gastos_por_porto = df.groupby("Porto")["Valor (USD)"].mean()

# Exibir o resultado
print(media_gastos_por_porto)
