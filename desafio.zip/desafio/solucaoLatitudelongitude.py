import pandas as pd
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

def reverse_geocode(lat, lon, geolocator):
    try:
        location = geolocator.reverse((lat, lon), timeout=10)
        return location.address
    except Exception as e:
        print(f"Error getting address for {lat}, {lon}: {e}")
        return None

def main():
    csv_file = "coordenadas_iguais.csv"
    df = pd.read_csv(csv_file, sep=',')

    geolocator = Nominatim(user_agent="geoapiExercises")
    geocode = RateLimiter(geolocator.reverse, min_delay_seconds=1)

    df['endereco'] = df.apply(lambda row: reverse_geocode(row['latitude'], row['longitude'], geolocator), axis=1)

    output_csv = "teste_cleaned_com_enderecos.csv"
    df.to_csv(output_csv, sep=';', index=False, encoding='utf-8')

    print(f"{output_csv} was successfully saved with addresses.")

if __name__ == "__main__":
    main()
