import pandas as pd
import matplotlib.pyplot as plt

# Ler o arquivo CSV com codificação latin1
df = pd.read_csv("taxas_portuarias_sem_espaco.csv", sep=",", encoding="latin1")

# Verificar visualmente as primeiras linhas do DataFrame
print(df.head())

# Verificar novamente as colunas
print("Colunas do DataFrame:", df.columns)

# Renomear as colunas
new_names = {"Valor_Por_Navio": "ValorporNavio", "Valor_Por_Tonelada": "ValorPorTonelada"}
df = df.rename(columns=new_names)

# Verificar se a renomeação foi bem-sucedida
print("Colunas renomeadas do DataFrame:", df.columns)

# Função para limpar e converter os valores para float
def limpar_valor(valor):
    if isinstance(valor, str):
        valor = valor.replace(' ', '')  # Remover espaços
        valor = valor.replace('$', '')  # Remover símbolo de moeda
        valor = valor.replace('.', '')  # Remover pontos de milhar
        valor = valor.replace(',', '.')  # Substituir vírgula decimal por ponto
    return float(valor)

# Aplicar a função de limpeza às colunas relevantes
df["ValorporNavio"] = df["ValorporNavio"].apply(limpar_valor)
df["ValorPorTonelada"] = df["ValorPorTonelada"].apply(limpar_valor)

# Calcular o custo médio por porto (por navio)
average_cost_per_ship = df.groupby("Porto")["ValorporNavio"].mean()

# Calcular o custo médio por porto (por tonelada)
average_cost_per_ton = df.groupby("Porto")["ValorPorTonelada"].mean()

# Verificar os resultados intermediários
print("Custo médio por navio por porto:\n", average_cost_per_ship)
print("Custo médio por tonelada por porto:\n", average_cost_per_ton)

# Criar um gráfico de barras para o custo médio por porto (por navio)
plt.figure(figsize=(10, 6))
plt.bar(average_cost_per_ship.index, average_cost_per_ship.values, color="b", label="Custo por Navio")
plt.xlabel("Porto")
plt.ylabel("Custo Médio (€)")
plt.title("Custo Médio por Porto (por Navio)")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.show()

# Criar um gráfico de barras para o custo médio por porto (por tonelada)
plt.figure(figsize=(10, 6))
plt.bar(average_cost_per_ton.index, average_cost_per_ton.values, color="g", label="Custo por Tonelada")
plt.xlabel("Porto")
plt.ylabel("Custo Médio (€)")
plt.title("Custo Médio por Porto (por Tonelada)")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.show()
