import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter

# Carregar os dados do arquivo CSV usando barras duplas
df = pd.read_csv('C:\\Users\\douglas.ferreira\\Pictures\\materias\\casadigital\\desafio\\custos_por_tipo_de_navio\\total_por_dia.csv', delimiter=';')

# Converter a coluna 'Data' para datetime
df['Data'] = pd.to_datetime(df['Data'])

# Criar o gráfico de linha
plt.figure(figsize=(12, 6))
plt.plot(df['Data'], df['Valor (USD)'], marker='o', linestyle='-', color='b')
plt.ylabel('Total Gasto (USD)')
plt.xlabel('Data')
plt.title('Total Gasto por Dia')
plt.grid(True)

# Configurar formato de data para mostrar apenas o dia
date_form = DateFormatter("%d")  # Formato para exibir apenas o dia
plt.gca().xaxis.set_major_formatter(date_form)

plt.xticks(df['Data'])

plt.xticks(rotation=45)  # Rotaciona os rótulos do eixo x para melhor visualização
plt.tight_layout()

# Exibir o gráfico
plt.show()
