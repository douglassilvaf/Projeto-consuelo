import pandas as pd
import matplotlib.pyplot as plt

# Carregar os dados do arquivo CSV usando ponto e vírgula como separador
# Utilizando barras duplas para escapar a barra invertida no caminho do arquivo
df = pd.read_csv('C:\\Users\\douglas.ferreira\\Pictures\\materias\\casadigital\\desafio\\custos_por_tipo_de_navio\\total_por_Tipo_de_Custo.csv', delimiter=';', decimal=',')

# Converter a coluna 'Valor (USD)' para números float
df['Valor (USD)'] = df['Valor (USD)'].str.replace(',', '.').astype(float)

# Criar o gráfico de barras
plt.figure(figsize=(10, 6))
bars = plt.bar(df['Tipo de Custo'], df['Valor (USD)'], color='b', alpha=0.7)  # Usar gráfico de barras para melhor visualização
plt.ylabel('Total Gasto (USD)')
plt.xlabel('Tipo de Custo')
plt.title('Total Gasto por Tipo de Custo')
plt.grid(True)

plt.xticks(rotation=45, ha='right')  # Rotaciona os rótulos do eixo x para melhor visualização

# Adicionar os valores acima das barras
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval + 20000, round(yval, 2), ha='center', va='bottom')

plt.tight_layout()

# Exibir o gráfico
plt.show()
