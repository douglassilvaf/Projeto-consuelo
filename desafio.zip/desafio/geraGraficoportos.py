import pandas as pd
import matplotlib.pyplot as plt

# Carregar os dados do arquivo CSV usando ponto e vírgula como separador
df = pd.read_csv('C:\\Users\\douglas.ferreira\\Pictures\\materias\\casadigital\\desafio\\custos_por_tipo_de_navio\\total_por_Porto.csv', delimiter=';', decimal=',')

# Converter a coluna 'Valor (USD)' para números float
df['Valor (USD)'] = df['Valor (USD)'].str.replace(',', '.').astype(float)

# Criar o gráfico de barras
plt.figure(figsize=(12, 6))
bars = plt.bar(df['Porto'], df['Valor (USD)'], color='b', alpha=0.7)  # Usar gráfico de barras para melhor visualização
plt.ylabel('Total Gasto (USD)')
plt.xlabel('Porto')
plt.title('Total Gasto por Porto')
plt.grid(True)

plt.xticks(rotation=45, ha='right')  # Rotaciona os rótulos do eixo x para melhor visualização

# Ajustar o limite inferior do eixo y para começar em zero
plt.ylim(0, df['Valor (USD)'].max() * 1.1)  # Definir o limite superior para 110% do valor máximo dos dados

# Adicionar os valores acima das barras
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval + 5000, round(yval, 2), ha='center', va='bottom')

plt.tight_layout()

# Exibir o gráfico
plt.show()
