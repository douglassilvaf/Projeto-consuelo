import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Caminho para o arquivo CSV das taxas portuárias
caminho_taxas_portuarias = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/taxas_portuarias.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_taxas = pd.read_csv(caminho_taxas_portuarias, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_taxas.head())

# Estatísticas descritivas
estatisticas = df_taxas.groupby(['Porto', 'Tipo_Taxa']).agg({
    'Valor_Por_Navio': ['mean', 'min', 'max', 'std'],
    'Valor_Por_Tonelada': ['mean', 'min', 'max', 'std']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas.columns = ['Porto', 'Tipo_Taxa', 'Media_Navio', 'Min_Navio', 'Max_Navio', 'Desvio_Padrao_Navio',
                        'Media_Tonelada', 'Min_Tonelada', 'Max_Tonelada', 'Desvio_Padrao_Tonelada']

# Exibindo as estatísticas descritivas
print(estatisticas)

# Gráfico de barras para média das taxas por navio
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Navio', hue='Tipo_Taxa', data=estatisticas)
plt.title('Média das Taxas por Navio, por Porto e Tipo de Taxa')
plt.xlabel('Porto')
plt.ylabel('Média da Taxa por Navio')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Taxa')
plt.tight_layout()
plt.show()

# Gráfico de barras para média das taxas por tonelada
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Tonelada', hue='Tipo_Taxa', data=estatisticas)
plt.title('Média das Taxas por Tonelada, por Porto e Tipo de Taxa')
plt.xlabel('Porto')
plt.ylabel('Média da Taxa por Tonelada')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Taxa')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio frigorífico
caminho_frigorifico = "C:/Users/Usuário/Desktop/Projeto Logistico/Desafio_Log/custos_por_tipo_de_navio/navio_frigorifico.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_frigorifico = pd.read_csv(caminho_frigorifico, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_frigorifico.head())

# Calculando o custo médio por navio frigorífico, agrupando por Porto e Tipo de Custo
estatisticas_frigorifico = df_frigorifico.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_frigorifico.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_frigorifico)

# Gráfico de barras para média dos custos por navio frigorífico por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_frigorifico)
plt.title('Média dos Custos por Navio Frigorífico, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Caminho para o arquivo CSV das taxas portuárias
caminho_taxas_portuarias = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/taxas_portuarias.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_taxas = pd.read_csv(caminho_taxas_portuarias, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_taxas.head())

# Estatísticas descritivas
estatisticas = df_taxas.groupby(['Porto', 'Tipo_Taxa']).agg({
    'Valor_Por_Navio': ['mean', 'min', 'max', 'std'],
    'Valor_Por_Tonelada': ['mean', 'min', 'max', 'std']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas.columns = ['Porto', 'Tipo_Taxa', 'Media_Navio', 'Min_Navio', 'Max_Navio', 'Desvio_Padrao_Navio',
                        'Media_Tonelada', 'Min_Tonelada', 'Max_Tonelada', 'Desvio_Padrao_Tonelada']

# Exibindo as estatísticas descritivas
print(estatisticas)

# Gráfico de barras para média das taxas por navio
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Navio', hue='Tipo_Taxa', data=estatisticas)
plt.title('Média das Taxas por Navio, por Porto e Tipo de Taxa')
plt.xlabel('Porto')
plt.ylabel('Média da Taxa por Navio')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Taxa')
plt.tight_layout()
plt.show()

# Gráfico de barras para média das taxas por tonelada
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Tonelada', hue='Tipo_Taxa', data=estatisticas)
plt.title('Média das Taxas por Tonelada, por Porto e Tipo de Taxa')
plt.xlabel('Porto')
plt.ylabel('Média da Taxa por Tonelada')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Taxa')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio frigorífico
caminho_frigorifico = "C:/Users/Usuário/Desktop/Projeto Logistico/Desafio_Log/custos_por_tipo_de_navio/navio_frigorifico.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_frigorifico = pd.read_csv(caminho_frigorifico, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_frigorifico.head())

# Calculando o custo médio por navio frigorífico, agrupando por Porto e Tipo de Custo
estatisticas_frigorifico = df_frigorifico.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_frigorifico.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_frigorifico)

# Gráfico de barras para média dos custos por navio frigorífico por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_frigorifico)
plt.title('Média dos Custos por Navio Frigorífico, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio carga geral
caminho_carga_geral = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_carga_geral.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_carga_geral = pd.read_csv(caminho_carga_geral, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_carga_geral.head())

# Calculando o custo médio por navio carga geral, agrupando por Porto e Tipo de Custo
estatisticas_carga_geral = df_carga_geral.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_carga_geral.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_carga_geral)

# Gráfico de barras para média dos custos por navio carga geral por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_carga_geral)
plt.title('Média dos Custos por Navio Carga Geral, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio graneleiro
caminho_graneleiro = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_graneleiro.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_graneleiro = pd.read_csv(caminho_graneleiro, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_graneleiro.head())

# Calculando o custo médio por navio graneleiro, agrupando por Porto e Tipo de Custo
estatisticas_graneleiro = df_graneleiro.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_graneleiro.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_graneleiro)

# Gráfico de barras para média dos custos por navio graneleiro por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_graneleiro)
plt.title('Média dos Custos por Navio Graneleiro, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio porta-contêiner
caminho_porta_conteiner = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_porta_conteiner.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_porta_conteiner = pd.read_csv(caminho_porta_conteiner, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_porta_conteiner.head())

# Calculando o custo médio por navio porta-contêiner, agrupando por Porto e Tipo de Custo
estatisticas_porta_conteiner = df_porta_conteiner.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_porta_conteiner.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_porta_conteiner)

# Gráfico de barras para média dos custos por navio porta-contêiner por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_porta_conteiner)
plt.title('Média dos Custos por Navio Porta-Contêiner, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio ro-ro
caminho_ro_ro = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_ro_ro.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_ro_ro = pd.read_csv(caminho_ro_ro, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_ro_ro.head())

# Calculando o custo médio por navio ro-ro, agrupando por Porto e Tipo de Custo
estatisticas_ro_ro = df_ro_ro.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_ro_ro.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_ro_ro)

# Gráfico de barras para média dos custos por navio ro-ro por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_ro_ro)
plt.title('Média dos Custos por Navio Ro-Ro, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio carga geral
caminho_carga_geral = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_carga_geral.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_carga_geral = pd.read_csv(caminho_carga_geral, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_carga_geral.head())

# Calculando o custo médio por navio carga geral, agrupando por Porto e Tipo de Custo
estatisticas_carga_geral = df_carga_geral.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_carga_geral.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_carga_geral)

# Gráfico de barras para média dos custos por navio carga geral por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_carga_geral)
plt.title('Média dos Custos por Navio Carga Geral, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio graneleiro
caminho_graneleiro = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_graneleiro.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_graneleiro = pd.read_csv(caminho_graneleiro, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_graneleiro.head())

# Calculando o custo médio por navio graneleiro, agrupando por Porto e Tipo de Custo
estatisticas_graneleiro = df_graneleiro.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_graneleiro.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_graneleiro)

# Gráfico de barras para média dos custos por navio graneleiro por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_graneleiro)
plt.title('Média dos Custos por Navio Graneleiro, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio porta-contêiner
caminho_porta_conteiner = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_porta_conteiner.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_porta_conteiner = pd.read_csv(caminho_porta_conteiner, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_porta_conteiner.head())

# Calculando o custo médio por navio porta-contêiner, agrupando por Porto e Tipo de Custo
estatisticas_porta_conteiner = df_porta_conteiner.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_porta_conteiner.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_porta_conteiner)

# Gráfico de barras para média dos custos por navio porta-contêiner por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_porta_conteiner)
plt.title('Média dos Custos por Navio Porta-Contêiner, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()

# Caminho para o arquivo CSV do navio ro-ro
caminho_ro_ro = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_ro_ro.csv"

# Carregando os dados do arquivo CSV para um DataFrame
df_ro_ro = pd.read_csv(caminho_ro_ro, delimiter=';')

# Visualizando os primeiros registros para verificação
print(df_ro_ro.head())

# Calculando o custo médio por navio ro-ro, agrupando por Porto e Tipo de Custo
estatisticas_ro_ro = df_ro_ro.groupby(['Porto', 'Tipo de Custo']).agg({
    'Valor (USD)': ['mean']
}).reset_index()

# Renomeando colunas para facilitar o entendimento
estatisticas_ro_ro.columns = ['Porto', 'Tipo de Custo', 'Media_Valor']

# Exibindo as estatísticas descritivas
print(estatisticas_ro_ro)

# Gráfico de barras para média dos custos por navio ro-ro por Porto e Tipo de Custo
plt.figure(figsize=(12, 8))
sns.barplot(x='Porto', y='Media_Valor', hue='Tipo de Custo', data=estatisticas_ro_ro)
plt.title('Média dos Custos por Navio Ro-Ro, por Porto e Tipo de Custo')
plt.xlabel('Porto')
plt.ylabel('Média do Custo (USD)')
plt.xticks(rotation=45)
plt.legend(title='Tipo de Custo')
plt.tight_layout()
plt.show()