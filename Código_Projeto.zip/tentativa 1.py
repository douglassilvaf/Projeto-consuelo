import pandas as pd
import matplotlib.pyplot as plt

# Função para carregar o CSV, calcular a média das taxas por porto e plotar o gráfico
def plot_mean_taxes(file_path, delimiter, title):
    # Carregar os dados do arquivo CSV
    df = pd.read_csv(file_path, delimiter=delimiter)
    
    # Verificar se o arquivo foi carregado corretamente
    print(f"Primeiras linhas do arquivo {file_path}:")
    print(df.head())
    
    # Calcular a média das taxas por porto
    # Considerando que a coluna 'Valor (USD)' representa as taxas
    mean_taxes_per_port = df.groupby('Porto')['Valor (USD)'].mean().reset_index()
    
    # Renomear a coluna para melhor entendimento
    mean_taxes_per_port.columns = ['Porto', 'Média das Taxas (USD)']
    
    # Plotar o gráfico
    plt.figure(figsize=(10, 6))
    plt.bar(mean_taxes_per_port['Porto'], mean_taxes_per_port['Média das Taxas (USD)'], color='skyblue')
    plt.xlabel('Porto')
    plt.ylabel('Média das Taxas (USD)')
    plt.title(title)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Exibir o gráfico
    plt.show()

# Caminhos para os arquivos
file_path_frigorifico = "C:/Users/Usuário/Desktop/Projeto Logistico/Desafio_Log/custos_por_tipo_de_navio/navio_frigorifico.csv"
file_path_carga_geral = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_carga_geral.csv"
file_path_porta_conteiner = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_porta_conteiner.csv"
file_path_ro_ro = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_ro_ro.csv"

# Delimitadores dos arquivos
delimiter = ';'

# Plotar gráficos para cada arquivo
plot_mean_taxes(file_path_frigorifico, delimiter, 'Média das Taxas nos Portos dos Navios Frigoríficos')
plot_mean_taxes(file_path_carga_geral, delimiter, 'Média das Taxas nos Portos dos Navios de Carga Geral')
plot_mean_taxes(file_path_porta_conteiner, delimiter, 'Média das Taxas nos Portos dos Navios Porta Contêiner')
plot_mean_taxes(file_path_ro_ro, delimiter, 'Média das Taxas nos Portos dos Navios Ro-Ro')
