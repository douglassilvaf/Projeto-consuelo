import pandas as pd
import matplotlib.pyplot as plt

# Função para carregar o CSV e criar o box plot
def plot_box_plot(file_path, delimiter, title):
    # Carregar os dados do arquivo CSV
    df = pd.read_csv(file_path, delimiter=delimiter)
    
    # Verificar os nomes das colunas
    print(f"Colunas no arquivo {file_path}: {df.columns}")
    
    # Verificar se a coluna 'Valor (USD)' está presente
    if 'Valor (USD)' in df.columns:
        # Criar o box plot para a coluna 'Valor (USD)'
        plt.figure(figsize=(8, 6))
        plt.boxplot(df['Valor (USD)'].dropna(), vert=True, patch_artist=True, 
                    boxprops=dict(facecolor='skyblue', color='blue'),
                    whiskerprops=dict(color='blue'),
                    capprops=dict(color='blue'),
                    medianprops=dict(color='red'))
        plt.ylabel('Valor (USD)')
        plt.title(title)
        plt.grid(True)
        plt.show()
    else:
        print(f"Coluna 'Valor (USD)' não encontrada no arquivo {file_path}. Verifique os nomes das colunas.")

# Caminhos para os arquivos
file_path_frigorifico = "C:/Users/Usuário/Desktop/Projeto Logistico/Desafio_Log/custos_por_tipo_de_navio/navio_frigorifico.csv"
file_path_carga_geral = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_carga_geral.csv"
file_path_porta_conteiner = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_porta_conteiner.csv"
file_path_ro_ro = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/navio_ro_ro.csv"

# Delimitadores dos arquivos
delimiter_frigorifico = ';'
delimiter_carga_geral = ';'
delimiter_porta_conteiner = ';'
delimiter_ro_ro = ';'

# Plotar box plot para o arquivo de navio frigorífico
plot_box_plot(file_path_frigorifico, delimiter_frigorifico, 'Box Plot das Taxas dos Navios Frigoríficos')

# Plotar box plot para o arquivo de navio de carga geral
plot_box_plot(file_path_carga_geral, delimiter_carga_geral, 'Box Plot das Taxas dos Navios de Carga Geral')

# Plotar box plot para o arquivo de navio porta contêiner
plot_box_plot(file_path_porta_conteiner, delimiter_porta_conteiner, 'Box Plot das Taxas dos Navios Porta Contêiner')

# Plotar box plot para o arquivo de navio ro-ro
plot_box_plot(file_path_ro_ro, delimiter_ro_ro, 'Box Plot das Taxas dos Navios Ro-Ro')
